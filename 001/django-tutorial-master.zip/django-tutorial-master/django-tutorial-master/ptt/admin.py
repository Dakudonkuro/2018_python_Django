# Register your models here.
from django.contrib import admin
from ptt.models import Music

admin.site.register(Music)
